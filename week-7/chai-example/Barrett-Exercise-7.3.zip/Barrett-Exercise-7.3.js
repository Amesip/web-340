/*
 Title: Chai Example
 Author: Richard Krasso
 Date: 4 6 2018
 Modified By: Mary Barrett
 Description: This code is the modified Chai example.

 */

function fruits(str) {

    return str.split(',');

}

module.exports = fruits;