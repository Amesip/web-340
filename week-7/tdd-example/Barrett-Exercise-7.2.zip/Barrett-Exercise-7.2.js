/*
 Title: TDD Example
 Author: Richard Krasso
 Date: 4 6 2018
 Modified By: Mary Barrett
 Description: This code is the modified TDD example.

 */

function getFruits(str) {

    return str.split(',');

   }

   module.exports = getFruits;